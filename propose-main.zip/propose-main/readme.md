# Propose Your Valentine

a lovely web template for couples who want to share their feelings with their special person.

live at: https://proposeme.netlify.app/

## How to use it?

first, go to this [link](https://proposeme.netlify.app/) and follow the instructions.

- enter your valentine's name in the input field and click the propose now button
- a popup will appear with a proposal link. just copy the link and share the link with your valentine

## Commands to run code

give _yarn_ or _npm install_ command to install all required packages.

```bash
yarn
```

use _lint_ script to install all updated linting packages.

```bash
yarn lint
```

then give _yarn dev_ or _npm run dev_ to start the developer server.

```bash
yarn dev
```
